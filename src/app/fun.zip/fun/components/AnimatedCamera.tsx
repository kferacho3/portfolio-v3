// src/components/AnimatedCamera.tsx
'use client';

import { PerspectiveCamera as DreiPerspectiveCamera } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import { easeCubicInOut } from 'd3-ease';
import React, { useEffect, useRef } from 'react';
import { CatmullRomCurve3, PerspectiveCamera as ThreePerspectiveCamera, Vector3 } from 'three';

interface AnimatedCameraProps {
  positions: [number, number, number][];
  lookAtPosition?: [number, number, number];
  onAnimationComplete: () => void;
  active?: boolean;
  duration?: number;
}

const MIN_DURATION = 6.4;
const MAX_DURATION = 12;
const SPEED_UNITS_PER_SEC = 6.5;

const AnimatedCamera: React.FC<AnimatedCameraProps> = ({
  positions,
  lookAtPosition = [0, 0, 0],
  onAnimationComplete,
  active = true,
  duration,
}) => {
  const cameraRef = useRef<ThreePerspectiveCamera>(null);
  const curveRef = useRef<CatmullRomCurve3 | null>(null);
  const startTimeRef = useRef<number | null>(null);
  const durationRef = useRef<number>(duration ?? MIN_DURATION);
  const completedRef = useRef(false);
  const lookAtRef = useRef(new Vector3(...lookAtPosition));
  const onCompleteRef = useRef(onAnimationComplete);
  const activeRef = useRef(active);

  useEffect(() => {
    onCompleteRef.current = onAnimationComplete;
  }, [onAnimationComplete]);

  useEffect(() => {
    lookAtRef.current.set(...lookAtPosition);
  }, [lookAtPosition]);

  useEffect(() => {
    activeRef.current = active;
  }, [active]);

  useEffect(() => {
    if (!positions.length) return;

    const points = positions.map((position) => new Vector3(...position));
    curveRef.current =
      points.length > 1
        ? new CatmullRomCurve3(points, false, 'centripetal', 0.35)
        : null;

    const initialPoint = active ? points[0] : points[points.length - 1];

    if (cameraRef.current) {
      cameraRef.current.position.copy(initialPoint);
      cameraRef.current.lookAt(lookAtRef.current);
      cameraRef.current.updateProjectionMatrix();
    }

    startTimeRef.current = null;
    completedRef.current = !active || points.length <= 1;

    if (points.length <= 1) {
      if (active) {
        onCompleteRef.current();
      }
      return;
    }

    if (duration !== undefined) {
      durationRef.current = duration;
      return;
    }

    const curve = curveRef.current;
    if (!curve) return;
    const lengths = curve.getLengths(200);
    const totalLength = lengths[lengths.length - 1] ?? 1;
    durationRef.current = clamp(totalLength / SPEED_UNITS_PER_SEC, MIN_DURATION, MAX_DURATION);
  }, [positions, duration, active]);

  useFrame((state) => {
    if (!activeRef.current || completedRef.current || !curveRef.current) return;

    if (startTimeRef.current === null) {
      startTimeRef.current = state.clock.elapsedTime;
      return;
    }

    const elapsed = state.clock.elapsedTime - startTimeRef.current;
    const totalDuration = Math.max(durationRef.current, 0.1);
    const rawT = Math.min(elapsed / totalDuration, 1);
    const easedT = easeCubicInOut(rawT);
    const point = curveRef.current.getPointAt(easedT);

    if (cameraRef.current) {
      cameraRef.current.position.copy(point);
      cameraRef.current.lookAt(lookAtRef.current);
    }

    if (rawT >= 1) {
      completedRef.current = true;
      onCompleteRef.current();
    }
  });

  return (
    <DreiPerspectiveCamera
      ref={cameraRef}
      makeDefault
      fov={60}
      near={0.1}
      far={1000}
      position={positions[0] ?? [0, 0, 0]}
    />
  );
};

const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));

export default AnimatedCamera;
