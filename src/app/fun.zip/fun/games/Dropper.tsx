// src/components/games/Dropper.tsx
'use client';

import { Physics, useBox } from '@react-three/cannon';
import { Html } from '@react-three/drei';
import { useFrame, useThree } from '@react-three/fiber';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { proxy } from 'valtio';

// Define the interface for Dropper's game state
export interface DropperState {
  score: number;
  reset: () => void;
}

// Initialize the game state
export const dropperState = proxy<DropperState>({
  score: 0,
  reset: () => {
    dropperState.score = 0;
  },
});

// Game constants
const BLOCK_SIZE: [number, number, number] = [3.5, 0.5, 3.5];
const OSCILLATION_AMPLITUDE = 4.5;
const BASE_OSCILLATION_SPEED = 600; // ms per cycle
const DROP_HEIGHT_OFFSET = 3.5; // Height above stack for oscillating block
const CAMERA_LEAD = 2.5; // How much camera leads above the oscillating block

// Block types
type BlockType = 'normal' | 'golden' | 'diamond' | 'rainbow';

interface BlockTypeConfig {
  points: number;
  speedMultiplier: number;
  probability: number;
}

const BLOCK_TYPES: Record<BlockType, BlockTypeConfig> = {
  normal: { points: 10, speedMultiplier: 1.0, probability: 0.7 },
  golden: { points: 50, speedMultiplier: 1.5, probability: 0.15 },
  diamond: { points: 100, speedMultiplier: 2.0, probability: 0.1 },
  rainbow: { points: 200, speedMultiplier: 2.5, probability: 0.05 },
};

// Get random block type based on probability
const getRandomBlockType = (): BlockType => {
  const rand = Math.random();
  let cumulative = 0;
  for (const [type, config] of Object.entries(BLOCK_TYPES)) {
    cumulative += config.probability;
    if (rand < cumulative) return type as BlockType;
  }
  return 'normal';
};

// Generate color based on block type
const getBlockColor = (type: BlockType): string => {
  switch (type) {
    case 'golden':
      return '#FFD700';
    case 'diamond':
      return '#00FFFF';
    case 'rainbow':
      return `hsl(${Date.now() % 360}, 80%, 60%)`; // Animated in shader
    default:
      const hue = Math.floor(Math.random() * 360);
      return `hsl(${hue}, 70%, 65%)`;
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// CAMERA CONTROLLER - Smooth following with the stack
// ═══════════════════════════════════════════════════════════════════════════

interface CameraControllerProps {
  highestY: number;
  oscillatingY: number;
}

const CameraController: React.FC<CameraControllerProps> = ({ highestY, oscillatingY }) => {
  const { camera } = useThree();
  const targetRef = useRef(new THREE.Vector3(0, 5, 18));
  const lookAtRef = useRef(new THREE.Vector3(0, 0, 0));

  useEffect(() => {
    camera.position.set(0, 5, 18);
    if ('fov' in camera) {
      (camera as THREE.PerspectiveCamera).fov = 45;
      camera.updateProjectionMatrix();
    }
  }, [camera]);

  useFrame(() => {
    // Camera should see both the stack and the oscillating block
    const viewCenterY = (highestY + oscillatingY) / 2;
    const cameraY = Math.max(5, oscillatingY + CAMERA_LEAD);
    const cameraZ = 18 + Math.max(0, highestY * 0.15); // Pull back as tower grows
    
    targetRef.current.set(0, cameraY, cameraZ);
    lookAtRef.current.set(0, viewCenterY, 0);
    
    // Smooth camera movement
    camera.position.lerp(targetRef.current, 0.08);
    
    // Smooth look-at
    const currentLookAt = new THREE.Vector3();
    camera.getWorldDirection(currentLookAt);
    const targetDirection = lookAtRef.current.clone().sub(camera.position).normalize();
    currentLookAt.lerp(targetDirection, 0.1);
    camera.lookAt(camera.position.clone().add(currentLookAt.multiplyScalar(10)));
  });

  return null;
};

// ═══════════════════════════════════════════════════════════════════════════
// SPECIAL BLOCK MATERIAL - Shader-based materials for special blocks
// ═══════════════════════════════════════════════════════════════════════════

interface SpecialBlockMaterialProps {
  type: BlockType;
  color: string;
}

const SpecialBlockMaterial: React.FC<SpecialBlockMaterialProps> = ({ type, color }) => {
  const materialRef = useRef<THREE.MeshPhysicalMaterial>(null);

  useFrame(({ clock }) => {
    if (!materialRef.current) return;
    const t = clock.getElapsedTime();

    switch (type) {
      case 'golden':
        materialRef.current.emissiveIntensity = 0.3 + 0.2 * Math.sin(t * 4);
        break;
      case 'diamond':
        materialRef.current.iridescence = 0.8 + 0.2 * Math.sin(t * 3);
        materialRef.current.emissiveIntensity = 0.2 + 0.1 * Math.sin(t * 5);
        break;
      case 'rainbow':
        const hue = (t * 100) % 360;
        materialRef.current.color.setHSL(hue / 360, 0.8, 0.6);
        materialRef.current.emissive.setHSL(hue / 360, 0.8, 0.3);
        materialRef.current.emissiveIntensity = 0.4 + 0.2 * Math.sin(t * 6);
        break;
    }
  });

  const materialProps = useMemo(() => {
    const baseColor = new THREE.Color(color);
    
    switch (type) {
      case 'golden':
        return {
          color: baseColor,
          metalness: 0.9,
          roughness: 0.1,
          emissive: new THREE.Color('#FFD700'),
          emissiveIntensity: 0.3,
          clearcoat: 1.0,
          clearcoatRoughness: 0.1,
        };
      case 'diamond':
        return {
          color: baseColor,
          metalness: 0.1,
          roughness: 0.0,
          transmission: 0.5,
          thickness: 0.5,
          ior: 2.4,
          iridescence: 1.0,
          iridescenceIOR: 2.0,
          iridescenceThicknessRange: [100, 400] as [number, number],
          emissive: new THREE.Color('#00FFFF'),
          emissiveIntensity: 0.2,
          clearcoat: 1.0,
          clearcoatRoughness: 0.0,
        };
      case 'rainbow':
        return {
          color: baseColor,
          metalness: 0.3,
          roughness: 0.2,
          emissive: baseColor,
          emissiveIntensity: 0.4,
          clearcoat: 0.8,
          clearcoatRoughness: 0.1,
        };
      default:
        return {
          color: baseColor,
          metalness: 0.1,
          roughness: 0.4,
        };
    }
  }, [type, color]);

  if (type === 'normal') {
    return <meshStandardMaterial color={color} />;
  }

  return (
    <meshPhysicalMaterial
      ref={materialRef}
      {...materialProps}
      side={THREE.DoubleSide}
    />
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// OSCILLATING BLOCK - The block player controls
// ═══════════════════════════════════════════════════════════════════════════

interface OscillatingBlockProps {
  position: [number, number, number];
  size: [number, number, number];
  type: BlockType;
  color: string;
}

const OscillatingBlock: React.FC<OscillatingBlockProps> = ({ position, size, type, color }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const targetPos = useRef(new THREE.Vector3(...position));

  useFrame(() => {
    if (!meshRef.current) return;
    targetPos.current.set(...position);
    meshRef.current.position.lerp(targetPos.current, 0.3);
    
    // Subtle wobble for special blocks
    if (type !== 'normal') {
      meshRef.current.rotation.z = Math.sin(Date.now() / 200) * 0.05;
    }
  });

  return (
    <group>
      <mesh ref={meshRef} position={position} castShadow>
        <boxGeometry args={size} />
        <SpecialBlockMaterial type={type} color={color} />
      </mesh>
      {/* Glow effect for special blocks */}
      {type !== 'normal' && (
        <mesh position={position} scale={1.1}>
          <boxGeometry args={size} />
          <meshBasicMaterial
            color={color}
            transparent
            opacity={0.2}
            side={THREE.BackSide}
          />
        </mesh>
      )}
      {/* Drop indicator line */}
      <line>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={2}
            array={new Float32Array([position[0], position[1], 0, position[0], -10, 0])}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#ffffff" transparent opacity={0.2} />
      </line>
    </group>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// STATIC BASE BLOCK
// ═══════════════════════════════════════════════════════════════════════════

interface StaticBlockProps {
  position: [number, number, number];
  size: [number, number, number];
  color: string;
}

const StaticBlock: React.FC<StaticBlockProps> = ({ position, size, color }) => {
  const [ref] = useBox<THREE.Mesh>(() => ({
    type: 'Static',
    position,
    args: size,
  }));

  return (
    <mesh ref={ref} receiveShadow castShadow>
      <boxGeometry args={size} />
      <meshStandardMaterial color={color} metalness={0.3} roughness={0.7} />
    </mesh>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// DROPPED BLOCK - Falls and becomes static
// ═══════════════════════════════════════════════════════════════════════════

interface DroppedBlockProps {
  position: [number, number, number];
  size: [number, number, number];
  type: BlockType;
  color: string;
  onLanded: (type: BlockType) => void;
}

const DroppedBlock: React.FC<DroppedBlockProps> = ({ position, size, type, color, onLanded }) => {
  const hasLanded = useRef(false);

  const [ref, api] = useBox<THREE.Mesh>(() => ({
    mass: 1,
    position,
    args: size,
    material: { friction: 0.95, restitution: 0.05 },
    linearDamping: 0.2,
    angularDamping: 0.5,
    onCollide: () => {
      if (!hasLanded.current) {
        hasLanded.current = true;
        // Freeze the block after collision
        setTimeout(() => {
          api.velocity.set(0, 0, 0);
          api.angularVelocity.set(0, 0, 0);
          api.mass.set(0);
        }, 100);
        onLanded(type);
      }
    },
  }));

  return (
    <group>
      <mesh ref={ref} castShadow receiveShadow>
        <boxGeometry args={size} />
        <SpecialBlockMaterial type={type} color={color} />
      </mesh>
    </group>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// BLOCK DATA
// ═══════════════════════════════════════════════════════════════════════════

interface BlockData {
  id: string;
  position: [number, number, number];
  size: [number, number, number];
  type: BlockType;
  color: string;
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN DROPPER COMPONENT
// ═══════════════════════════════════════════════════════════════════════════

interface DropperProps {
  soundsOn?: boolean;
}

const Dropper: React.FC<DropperProps> = ({ soundsOn: _soundsOn = true }) => {
  const [score, setScore] = useState(0);
  const [blocks, setBlocks] = useState<BlockData[]>([]);
  const [highestY, setHighestY] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [combo, setCombo] = useState(0);
  
  // Current block state
  const [currentBlockType, setCurrentBlockType] = useState<BlockType>('normal');
  const [currentColor, setCurrentColor] = useState(() => getBlockColor('normal'));
  
  // Refs for smooth animation
  const oscillatingXRef = useRef(0);
  const oscillatingYRef = useRef(DROP_HEIGHT_OFFSET);
  const speedMultiplierRef = useRef(1);

  // Sync score with global state
  useEffect(() => {
    dropperState.score = score;
  }, [score]);

  // Generate next block
  const generateNextBlock = useCallback(() => {
    const type = getRandomBlockType();
    setCurrentBlockType(type);
    setCurrentColor(getBlockColor(type));
    speedMultiplierRef.current = BLOCK_TYPES[type].speedMultiplier;
  }, []);

  // Reset function
  const reset = useCallback(() => {
    setScore(0);
    setBlocks([]);
    setHighestY(0);
    setGameOver(false);
    setCombo(0);
    generateNextBlock();
    oscillatingXRef.current = 0;
    oscillatingYRef.current = DROP_HEIGHT_OFFSET;
  }, [generateNextBlock]);

  useEffect(() => {
    dropperState.reset = reset;
    generateNextBlock();
  }, [reset, generateNextBlock]);

  // Oscillation animation
  useFrame(() => {
    if (gameOver) return;
    
    const now = Date.now();
    const speed = BASE_OSCILLATION_SPEED / speedMultiplierRef.current;
    oscillatingXRef.current = Math.sin(now / speed * Math.PI * 2 / 1000) * OSCILLATION_AMPLITUDE;
    oscillatingYRef.current = highestY + BLOCK_SIZE[1] + DROP_HEIGHT_OFFSET;
  });

  // Handle drop
  const handleDrop = useCallback(() => {
    if (gameOver) return;

    const dropPosition: [number, number, number] = [
      oscillatingXRef.current,
      highestY + BLOCK_SIZE[1] + 0.26,
      0,
    ];

    const newBlock: BlockData = {
      id: `block-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      position: dropPosition,
      size: BLOCK_SIZE,
      type: currentBlockType,
      color: currentColor,
    };

    setBlocks((prev) => [...prev, newBlock]);
    setHighestY(dropPosition[1]);
    generateNextBlock();
  }, [gameOver, highestY, currentBlockType, currentColor, generateNextBlock]);

  // Handle block landing
  const handleBlockLanded = useCallback((type: BlockType) => {
    const points = BLOCK_TYPES[type].points;
    const comboBonus = Math.floor(combo * 5);
    setScore((prev) => prev + points + comboBonus);
    setCombo((prev) => prev + 1);
  }, [combo]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.code === 'Space') {
        event.preventDefault();
        handleDrop();
      } else if (event.key.toLowerCase() === 'r') {
        reset();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleDrop, reset]);

  // Current oscillating position
  const oscillatingPosition: [number, number, number] = [
    oscillatingXRef.current,
    oscillatingYRef.current,
    0,
  ];

  return (
    <>
      <CameraController highestY={highestY} oscillatingY={oscillatingYRef.current} />
      
      {/* HUD */}
      <Html fullscreen>
        <div className="absolute top-4 left-4 rounded-xl border border-white/10 bg-slate-950/80 backdrop-blur-sm px-5 py-4 text-white shadow-xl">
          <div className="text-2xl font-bold">{score}</div>
          <div className="text-xs text-white/50 uppercase tracking-wider">Score</div>
          
          <div className="mt-3 flex gap-4">
            <div>
              <div className="text-lg font-semibold">{blocks.length}</div>
              <div className="text-xs text-white/50">Blocks</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-yellow-400">{combo}x</div>
              <div className="text-xs text-white/50">Combo</div>
            </div>
          </div>

          {/* Current block indicator */}
          <div className="mt-3 pt-3 border-t border-white/10">
            <div className="text-xs text-white/50 mb-1">Next Block:</div>
            <div className={`text-sm font-semibold ${
              currentBlockType === 'golden' ? 'text-yellow-400' :
              currentBlockType === 'diamond' ? 'text-cyan-400' :
              currentBlockType === 'rainbow' ? 'text-pink-400' :
              'text-white/70'
            }`}>
              {currentBlockType === 'normal' ? 'Normal (10pts)' :
               currentBlockType === 'golden' ? '★ Golden (50pts)' :
               currentBlockType === 'diamond' ? '◆ Diamond (100pts)' :
               '✦ Rainbow (200pts)'}
            </div>
          </div>

          <div className="text-xs text-white/40 mt-3">Press SPACE to drop</div>
          {gameOver && <div className="text-red-400 mt-2 font-semibold">Game Over - press R</div>}
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-xs text-white/60">
          <div className="flex gap-3">
            <span>Normal: 10pts</span>
            <span className="text-yellow-400">Golden: 50pts (faster)</span>
            <span className="text-cyan-400">Diamond: 100pts</span>
            <span className="text-pink-400">Rainbow: 200pts</span>
          </div>
        </div>
      </Html>

      {/* Lighting */}
      <ambientLight intensity={0.5} />
      <directionalLight 
        position={[10, 20, 10]} 
        intensity={1.5} 
        castShadow 
        shadow-mapSize={[2048, 2048]}
      />
      <directionalLight position={[-5, 10, -5]} intensity={0.4} color="#88aaff" />
      <pointLight position={[0, highestY + 5, 5]} intensity={0.5} color="#ffffff" />

      {/* Physics world */}
      <Physics gravity={[0, -35, 0]}>
        {/* Base platform */}
        <StaticBlock position={[0, -0.25, 0]} size={[5, 0.5, 5]} color="#3b82f6" />

        {/* Dropped blocks */}
        {blocks.map((block) => (
          <DroppedBlock
            key={block.id}
            position={block.position}
            size={block.size}
            type={block.type}
            color={block.color}
            onLanded={handleBlockLanded}
          />
        ))}
      </Physics>

      {/* Oscillating block (outside physics - visual only) */}
      {!gameOver && (
        <OscillatingBlock
          position={oscillatingPosition}
          size={BLOCK_SIZE}
          type={currentBlockType}
          color={currentColor}
        />
      )}

      {/* Ground reference grid */}
      <gridHelper args={[20, 20, '#333333', '#222222']} position={[0, -0.5, 0]} />
    </>
  );
};

export default Dropper;
