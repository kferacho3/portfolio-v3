// src/components/Stackz.tsx
'use client';

import { Html } from '@react-three/drei';
import { useFrame, useThree } from '@react-three/fiber';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { proxy } from 'valtio';
import * as THREE from 'three';

// Define the interface for Stackz's game state
export interface StackzState {
  score: number;
  reset: () => void;
}

// Initialize the game state
export const stackzState = proxy<StackzState>({
  score: 0,
  reset: () => {
    stackzState.score = 0;
  },
});

interface StackBlock {
  position: [number, number, number];
  size: [number, number, number];
  color: string;
}

const BASE_SIZE: [number, number, number] = [4, 0.4, 4];
const MOVE_RANGE = 6;
const MOVE_SPEED = 3;
const BLOCK_HEIGHT = 0.5;

interface StackzProps {
  soundsOn?: boolean;
}

const Stackz: React.FC<StackzProps> = ({ soundsOn: _soundsOn = true }) => {
  const [stack, setStack] = useState<StackBlock[]>([
    { position: [0, -3, 0], size: BASE_SIZE, color: '#facc15' },
  ]);
  const [currentSize, setCurrentSize] = useState<[number, number, number]>(BASE_SIZE);
  const [currentY, setCurrentY] = useState(-3 + BLOCK_HEIGHT);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const lastPlaceRef = useRef(0);
  const movingXRef = useRef(-MOVE_RANGE);
  const directionRef = useRef(1);
  const movingMeshRef = useRef<THREE.Mesh>(null);
  const { camera } = useThree();

  useEffect(() => {
    stackzState.score = score;
  }, [score]);

  const reset = useCallback(() => {
    setStack([{ position: [0, -3, 0], size: BASE_SIZE, color: '#facc15' }]);
    setCurrentSize(BASE_SIZE);
    setCurrentY(-3 + BLOCK_HEIGHT);
    movingXRef.current = -MOVE_RANGE;
    directionRef.current = 1;
    setScore(0);
    setGameOver(false);
  }, []);

  useEffect(() => {
    stackzState.reset = reset;
  }, [reset]);

  const placeBlock = useCallback(() => {
    if (gameOver) {
      reset();
      return;
    }

    const now = Date.now();
    if (now - lastPlaceRef.current < 150) return;
    lastPlaceRef.current = now;

    const top = stack[stack.length - 1];
    const [topX] = top.position;
    const [topWidth] = top.size;
    const currX = movingXRef.current;
    const currY = currentY;
    const currZ = 0;
    const currWidth = currentSize[0];

    const topLeft = topX - topWidth / 2;
    const topRight = topX + topWidth / 2;
    const currLeft = currX - currWidth / 2;
    const currRight = currX + currWidth / 2;

    const overlapLeft = Math.max(topLeft, currLeft);
    const overlapRight = Math.min(topRight, currRight);
    const overlap = overlapRight - overlapLeft;

    if (overlap <= 0.2) {
      setGameOver(true);
      return;
    }

    const newWidth = overlap;
    const newX = (overlapLeft + overlapRight) / 2;
    const newBlock: StackBlock = {
      position: [newX, currY, currZ],
      size: [newWidth, currentSize[1], currentSize[2]],
      color: '#38bdf8',
    };

    setStack((prev) => [...prev, newBlock]);
    setScore((prev) => prev + Math.round(overlap * 10));

    const nextY = currY + BLOCK_HEIGHT;
    setCurrentY(nextY);
    setCurrentSize([newWidth, currentSize[1], currentSize[2]]);
    directionRef.current *= -1;
    movingXRef.current = directionRef.current > 0 ? -MOVE_RANGE : MOVE_RANGE;
  }, [currentSize, currentY, gameOver, reset, stack]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.code === 'Space') placeBlock();
      if (event.key.toLowerCase() === 'r') reset();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [placeBlock, reset]);

  useFrame((_, delta) => {
    if (gameOver) return;
    let nextX = movingXRef.current + directionRef.current * MOVE_SPEED * delta;
    if (nextX > MOVE_RANGE) {
      nextX = MOVE_RANGE;
      directionRef.current = -1;
    }
    if (nextX < -MOVE_RANGE) {
      nextX = -MOVE_RANGE;
      directionRef.current = 1;
    }
    movingXRef.current = nextX;
    if (movingMeshRef.current) {
      movingMeshRef.current.position.x = nextX;
      movingMeshRef.current.position.y = currentY;
    }
    camera.position.set(0, Math.max(4, currentY + 4), 12);
    camera.lookAt(0, currentY - 2, 0);
  });

  return (
    <>
      <Html center>
        <div className="pointer-events-none rounded-xl border border-white/10 bg-slate-950/70 px-4 py-2 text-sm text-white shadow">
          <div className="font-semibold">Score: {score}</div>
          <div>Press Space to place</div>
          {gameOver && <div className="text-red-400">Missed! Press Space to restart</div>}
        </div>
      </Html>
      <ambientLight intensity={0.6} />
      <directionalLight position={[6, 10, 6]} intensity={0.9} />
      <group>
        {stack.map((block, index) => (
          <mesh key={`stack-${index}`} position={block.position} castShadow receiveShadow>
            <boxGeometry args={block.size} />
            <meshStandardMaterial color={block.color} />
          </mesh>
        ))}
        {!gameOver && (
          <mesh ref={movingMeshRef} position={[movingXRef.current, currentY, 0]} castShadow>
            <boxGeometry args={currentSize} />
            <meshStandardMaterial color="#38bdf8" />
          </mesh>
        )}
      </group>
    </>
  );
};

export default Stackz;
